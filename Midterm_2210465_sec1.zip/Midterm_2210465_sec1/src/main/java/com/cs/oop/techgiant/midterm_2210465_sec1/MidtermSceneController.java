package com.cs.oop.techgiant.midterm_2210465_sec1;

import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.ArrayList;

public class MidtermSceneController
{
    @javafx.fxml.FXML
    private TextField MinPriceTextField;
    @javafx.fxml.FXML
    private TableColumn genreCol;
    @javafx.fxml.FXML
    private TextField MaxFieldTextField;
    @javafx.fxml.FXML
    private ComboBox<String> bookGenreComboBox;
    @javafx.fxml.FXML
    private ComboBox<String> selectGenreComboBox;
    @javafx.fxml.FXML
    private TableColumn<DummyClass,Integer> bookIdCol;
    @javafx.fxml.FXML
    private TableColumn<DummyClass,Float> priceCol;
    @javafx.fxml.FXML
    private TableColumn<DummyClass,String> bookTitleCol;
    @javafx.fxml.FXML
    private Button addNewBookButton;
    @javafx.fxml.FXML
    private Button searchShowButton;
    @javafx.fxml.FXML
    private TableColumn<DummyClass,Integer> totalBookCountCol;
    @javafx.fxml.FXML
    private TextField priceTextField;
    @javafx.fxml.FXML
    private TableView<DummyClass> booklistTableView;
    @javafx.fxml.FXML
    private TextField bookIdTextField;
    @javafx.fxml.FXML
    private TextField bookTitleTextField;

    ArrayList<DummyClass> bookList;
    @javafx.fxml.FXML
    private Label errorLabel;

    @javafx.fxml.FXML
    public void initialize() {
        bookGenreComboBox.getItems().addAll("Fantasy","Romance","Thriller");
        selectGenreComboBox.getItems().addAll("Fantasy","Romance","Thriller");

        //Defaults
        bookGenreComboBox.setValue("Select Genre");
        selectGenreComboBox.setValue("Select Genre");

        bookIdCol.setCellValueFactory(new PropertyValueFactory<>("bookId"));
        bookTitleCol.setCellValueFactory(new PropertyValueFactory<>("bookTitle"));
        genreCol.setCellValueFactory(new PropertyValueFactory<>("bookGenre"));
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        totalBookCountCol.setCellValueFactory(new PropertyValueFactory<>("totalBookCount"));

        bookList = new ArrayList<DummyClass>();

    }

    @javafx.fxml.FXML
    public void searchShowButtonOnClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void selectBookGenreComboBoxOnClick(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void addNewBookButtonOnClick(ActionEvent actionEvent) {
        int id = Integer.parseInt(bookIdTextField.getId());
        String title = bookTitleTextField.getText();
        String genre = bookGenreComboBox.getValue();
        float price = Float.parseFloat(priceTextField.getText());
        int count = 0;

        DummyClass book = new DummyClass(id, title,genre,price,count);
        if(priceTextField==0){
            errorLabel.setText("Please enter a price");

        }
        else
            booklistTableView.getItems().add(book);



    }

    @javafx.fxml.FXML
    public void selectGenreToFilterOnClick(ActionEvent actionEvent) {
    }
}