module com.cs.oop.techgiant.midterm_2210465_sec1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.cs.oop.techgiant.midterm_2210465_sec1 to javafx.fxml;
    exports com.cs.oop.techgiant.midterm_2210465_sec1;
}